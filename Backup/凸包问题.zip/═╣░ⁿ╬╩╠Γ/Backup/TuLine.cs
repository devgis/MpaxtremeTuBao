﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace 凸包问题
{
    /// <summary>
    /// 凸包连线
    /// </summary>
    struct TuLine
    {
        public Point Begin;
        public Point End;
    }
}
